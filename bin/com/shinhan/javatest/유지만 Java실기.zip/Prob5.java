package com.shinhan.javatest;

public class Prob5 {
	public static void main(String[] args) {
		int[] answer = { 1, 4, 4, 3, 1, 4, 4, 2, 1, 3, 2 };
		int[] counter = new int[4];

		// 구현하시오 - 숫자들의 개수를 세어 저장하는 코드를 작성한다.
		
		for(int arr:answer) {
			if(arr==1) counter[0]++;
			else if(arr==2) counter[1]++;
			else if(arr==3) counter[2]++;
			else if(arr==4) counter[3]++;
		}
		
		
		// 구현하시오 - 출력결과와 같이 나오도록 작성한다.
		for(int i=0;i<4;i++) {
			System.out.println((i+1)+"의 갯수는"+counter[i]+"개입니다.");
		}
		

	}
}
